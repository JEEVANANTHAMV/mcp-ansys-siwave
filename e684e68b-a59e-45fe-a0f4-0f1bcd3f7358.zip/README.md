# Ansys SIwave (planar EM / signal integrity) MCP

Per-product offline MCP server. See SKILL.md for usage.

* pip client: pyaedt
* top-level import: ansys.aedt
* kind: grpc
* env: ANSYS_ROOT
